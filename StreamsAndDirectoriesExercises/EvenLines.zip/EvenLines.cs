﻿namespace EvenLines
{
    using System;
    using System.IO;
    using System.Text;
    using System.Linq;
    public class EvenLines
    {
        /*
         // 1. Създаваме StringBuilder, за да събираме резултатите

            // 2. Отваряме StreamReader върху файла (using конструкция)

            // 3. Четем ред по ред (с помощта на ReadLine)
            //    -> броим редовете (lineIndex = 0, 1, 2, …)

            // 4. Проверяваме дали редът е четен (lineIndex % 2 == 0)
            //    - Ако е четен:
            //        * заменяме символите {'-', ',', '.', '!', '?'} със '@'
            //        * разделяме реда по интервали
            //        * обръщаме реда на думите
            //        * добавяме обработения ред в StringBuilder

            // 5. Накрая връщаме резултата като string (ToString на StringBuilder)
         */

        static void Main()
        {
            string inputFilePath = @"../../../text.txt";

            Console.WriteLine(ProcessLines(inputFilePath));
            Console.ReadKey();
        }

        public static string ProcessLines(string inputFilePath)
        {
            StringBuilder result = new StringBuilder();

            using (var reader = new StreamReader(inputFilePath))
            {
                string line = string.Empty;
                int lineIndex = 0;

                while((line = reader.ReadLine()) != null)
                {
                    if (lineIndex % 2 == 0)
                    {
                        char[] symbols = { '-', ',', '.', '!', '?' };
                        foreach (var symbol in symbols)
                        {
                            line = line.Replace(symbol, '@');
                        }

                        string[] words = line.Split(" ", StringSplitOptions.RemoveEmptyEntries);
                        Array.Reverse(words);
                        string reversed = string.Join(" ", words);

                        result.AppendLine(reversed);
                    }
                    lineIndex++;
                }
                return result.ToString();
            } 
        }
    }
}
