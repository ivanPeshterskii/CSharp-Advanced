﻿namespace LineNumbers
{
    using System;
    using System.IO;
    using System.Linq;
    public class LineNumbers
    {
        static void Main()
        {
            string inputFilePath = @"../../../text.txt";
            string outputFilePath = @"../../../output.txt";

            ProcessLines(inputFilePath, outputFilePath);
        }

        public static void ProcessLines(string inputFilePath, string outputFilePath)
        {
            string[] lines = File.ReadAllLines(inputFilePath);

            string[] output = new string[lines.Length];

            for (int i = 0; i < lines.Length; i++)
            {
                string line = lines[i];

                int countLetters = line.Count(char.IsLetter);

                int countSybmbols = line.Count(char.IsPunctuation);

                output[i] = $"Line {i + 1}: {line} ({countLetters})({countSybmbols})";
            }

            File.WriteAllLines(outputFilePath, output);
        }
    }
}
